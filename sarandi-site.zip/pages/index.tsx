import SarandiMaisVerde from './SarandiMaisVerde';
export default SarandiMaisVerde;